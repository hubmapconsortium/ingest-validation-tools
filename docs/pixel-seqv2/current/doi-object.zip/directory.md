# Pixel Seqv2

## File Hierarchy Schema

 This table details the file hierarchy schema specification.

| Pattern | Required? | Description |
|--|--|--|
| extras/ | ✓ | Folder for general lab-specific files related to the dataset. |
| raw/ | ✓ | This is a directory containing raw data. |
| raw/pixel_seqv2/ |  | All relevant raw files for Pixel-seq v2. |
| lab_processed/ | ✓ | Experiment files that were processed by the lab generating the data. |
| lab_processed/pixel_seqv2/ |  | Experiment files that were processed by the lab generating the data exclusive to Pixel-seq v2. |


## Directory Tree

Here the file hierarchy schema is represented as a directory tree.

```
.
├── extras/
├── raw/
│   └── pixel_seqv2/
└── lab_processed/
    └── pixel_seqv2/
```

## YAML

This is file hierarchy schema as YAML code that can be use with the HuBMAP [Ingest Validation Tools](https://github.com/hubmapconsortium/ingest-validation-tools)

```yaml
files:
- pattern: extras\/.*
  required: true
  description: Folder for general lab-specific files related to the dataset.
- pattern: raw\/.*
  required: true
  description: This is a directory containing raw data.
- pattern: raw\/pixel_seqv2\/.*
  required: false
  description: All relevant raw files for Pixel-seq v2.
- pattern: lab_processed\/.*
  required: true
  description: Experiment files that were processed by the lab generating the data.
- pattern: lab_processed\/pixel_seqv2\/.*
  required: false
  description: Experiment files that were processed by the lab generating the data
    exclusive to Pixel-seq v2.
```
