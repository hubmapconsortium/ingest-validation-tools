# Dna Methylation

## File Hierarchy Schema

 This table details the file hierarchy schema specification.

| Pattern | Required? | Description |
|--|--|--|
| extras/ | ✓ | Folder for general lab-specific files related to the dataset. |
| raw/ | ✓ | This is a directory containing raw data. |
| raw/dnamethylation/ |  | All relevant raw files for DNA Methylation. |
| lab_processed/ | ✓ | Experiment files that were processed by the lab generating the data. |
| lab_processed/dnamethylation/ |  | All relevant experiment files for DNA Methylation. |


## Directory Tree

Here the file hierarchy schema is represented as a directory tree.

```
.
├── extras/
├── raw/
│   └── dnamethylation/
└── lab_processed/
    └── dnamethylation/
```

## YAML

This is file hierarchy schema as YAML code that can be use with the HuBMAP [Ingest Validation Tools](https://github.com/hubmapconsortium/ingest-validation-tools)

```yaml
files:
- pattern: extras\/.*
  required: true
  description: Folder for general lab-specific files related to the dataset.
- pattern: raw\/.*
  required: true
  description: This is a directory containing raw data.
- pattern: raw\/dnamethylation\/.*
  required: false
  description: All relevant raw files for DNA Methylation.
- pattern: lab_processed\/.*
  required: true
  description: Experiment files that were processed by the lab generating the data.
- pattern: lab_processed\/dnamethylation\/.*
  required: false
  description: All relevant experiment files for DNA Methylation.
```
