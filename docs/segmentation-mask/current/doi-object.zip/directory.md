# Segmentation Mask

## File Hierarchy Schema

 This table details the file hierarchy schema specification.

| Pattern | Required? | Description |
|--|--|--|
| extras/ | ✓ | Folder for general lab-specific files related to the dataset. |
| derived/ | ✓ | The EPIC data is placed in TOP/derived/ so it does not conflict with any files if it is uploaded with a primary dataset. |
| derived/extras/ | ✓ | Folder for general lab-specific files related to the derived dataset. |
| derived/segmentation_masks/ | ✓ | Directory containing segmentation masks. |
| derived/segmentation_masks/*.segmentations.ome.tiff$ | ✓ | The segmentation masks should be stored as multi-channel pyramidal OME TIFF bitmasks with one channel per mask, where a single mask contains all instances of a type of object (e.g., all cells, a class of FTUs, etc). The class of objects contained in the mask is documented in the segmentation-masks.csv file. Each individual object in a mask should be represented by a unique integer pixel value starting at 1, with 0 meaning background (e.g., all pixels belonging to the first instance of a T-cell have a value of 1, the pixels for the second instance of a T-cell have a value of 2, etc). The pixel values should be unique within a mask. FTUs and other structural elements should be captured the same way as cells with segmentation masks and the appropriate channel feature definitions. |
| derived/segmentation_masks/*-objects.{xlsx,tsv}$ | ✓ | This is a matrix where each row describes an individual object (e.g., one row per cell in the case where a mask contains all cells) and columns are features (i.e., object type, marker intensity, classification strategies, etc). One file should be created per mask with the name of the mask prepended to the file name. For example, if there's a cell segmentation map called 'cells' then you would include a file called 'cells-objects.xlsx' or 'cells-objects.tsv' and that file would contain one row per cell in the 'cells' mask and one column per feature, such as marker intensity and/or cell type. Ability to upload as TSV added to accommodate files with more rows than allowed by Excel. |
| derived/segmentation_masks/*-centroid-adjacency.csv$ |  | Objects are required to be in the same mask. A separate centroid-adjacency file can be included per mask. |
| derived/segmentation_masks/*-linkage-adjacency.csv$ |  | Objects are required to be in the same mask. A separate linkage-adjacency file can be included per mask. |
| derived/segmentation_masks/*-mesh.glb$ |  | This is a file with 3D mesh images for a 3D map. |
| derived/segmentation_masks/transformations/ |  | This directory should include any transformation files that pertain to a 3D reconstruction from serial sections. The mask protocol should explain the structure of these transformation files and how they can be used to reconstruct the 3D map from the 2D sections. |


## Directory Tree

Here the file hierarchy schema is represented as a directory tree.

```
.
├── extras/
└── derived/
    ├── extras/
    └── segmentation_masks/
        ├── *.segmentations.ome.tiff$
        ├── *-objects.{xlsx,tsv}$
        ├── *-centroid-adjacency.csv$
        ├── *-linkage-adjacency.csv$
        ├── *-mesh.glb$
        └── transformations/
```

## YAML

This is file hierarchy schema as YAML code that can be use with the HuBMAP [Ingest Validation Tools](https://github.com/hubmapconsortium/ingest-validation-tools)

```yaml
files:
- pattern: extras\/.*
  required: true
  description: Folder for general lab-specific files related to the dataset.
- pattern: derived\/.*
  required: true
  description: The EPIC data is placed in TOP/derived/ so it does not conflict with
    any files if it is uploaded with a primary dataset.
- pattern: derived\/extras\/.*
  required: true
  description: Folder for general lab-specific files related to the derived dataset.
- pattern: derived\/segmentation_masks\/.*
  required: true
  description: Directory containing segmentation masks.
- pattern: derived\/segmentation_masks\/[^\/]+\.segmentations\.ome\.tiff$
  required: true
  description: The segmentation masks should be stored as multi-channel pyramidal
    OME TIFF bitmasks with one channel per mask, where a single mask contains all
    instances of a type of object (e.g., all cells, a class of FTUs, etc). The class
    of objects contained in the mask is documented in the segmentation-masks.csv file.
    Each individual object in a mask should be represented by a unique integer pixel
    value starting at 1, with 0 meaning background (e.g., all pixels belonging to
    the first instance of a T-cell have a value of 1, the pixels for the second instance
    of a T-cell have a value of 2, etc). The pixel values should be unique within
    a mask. FTUs and other structural elements should be captured the same way as
    cells with segmentation masks and the appropriate channel feature definitions.
  is_qa_qc: false
- pattern: derived\/segmentation_masks\/[^\/]+-objects\.(?:xlsx|tsv)$
  required: true
  description: This is a matrix where each row describes an individual object (e.g.,
    one row per cell in the case where a mask contains all cells) and columns are
    features (i.e., object type, marker intensity, classification strategies, etc).
    One file should be created per mask with the name of the mask prepended to the
    file name. For example, if there's a cell segmentation map called 'cells' then
    you would include a file called 'cells-objects.xlsx' or 'cells-objects.tsv' and
    that file would contain one row per cell in the 'cells' mask and one column per
    feature, such as marker intensity and/or cell type. Ability to upload as TSV added
    to accommodate files with more rows than allowed by Excel.
  is_qa_qc: false
- pattern: derived\/segmentation_masks\/[^\/]+-centroid-adjacency\.csv$
  required: false
  description: Objects are required to be in the same mask. A separate centroid-adjacency
    file can be included per mask.
  is_qa_qc: false
- pattern: derived\/segmentation_masks\/[^\/]+-linkage-adjacency\.csv$
  required: false
  description: Objects are required to be in the same mask. A separate linkage-adjacency
    file can be included per mask.
  is_qa_qc: false
- pattern: derived\/segmentation_masks\/[^\/]+-mesh\.glb$
  required: false
  description: This is a file with 3D mesh images for a 3D map.
  is_qa_qc: false
- pattern: derived\/segmentation_masks\/transformations\/.*
  required: false
  description: This directory should include any transformation files that pertain
    to a 3D reconstruction from serial sections. The mask protocol should explain
    the structure of these transformation files and how they can be used to reconstruct
    the 3D map from the 2D sections.
```
