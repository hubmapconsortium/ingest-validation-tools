# Snm3C Seq

## File Hierarchy Schema

 This table details the file hierarchy schema specification.

| Pattern | Required? | Description |
|--|--|--|
| extras/ | ✓ | Folder for general lab-specific files related to the dataset. |
| raw/ | ✓ | This is a directory containing raw data. |
| raw/snm3C_seq/ |  | All relevant raw files for snm3C-seq. |
| lab_processed/ | ✓ | Experiment files that were processed by the lab generating the data. |
| lab_processed/snm3C_seq/ |  | All relevant experiment files for snm3C-seq. |


## Directory Tree

Here the file hierarchy schema is represented as a directory tree.

```
.
├── extras/
├── raw/
│   └── snm3C_seq/
└── lab_processed/
    └── snm3C_seq/
```

## YAML

This is file hierarchy schema as YAML code that can be use with the HuBMAP [Ingest Validation Tools](https://github.com/hubmapconsortium/ingest-validation-tools)

```yaml
files:
- pattern: extras\/.*
  required: true
  description: Folder for general lab-specific files related to the dataset.
- pattern: raw\/.*
  required: true
  description: This is a directory containing raw data.
- pattern: raw\/snm3C_seq\/.*
  required: false
  description: All relevant raw files for snm3C-seq.
- pattern: lab_processed\/.*
  required: true
  description: Experiment files that were processed by the lab generating the data.
- pattern: lab_processed\/snm3C_seq\/.*
  required: false
  description: All relevant experiment files for snm3C-seq.
```
