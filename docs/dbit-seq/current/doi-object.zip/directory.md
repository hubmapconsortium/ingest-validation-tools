# Dbit Seq

## File Hierarchy Schema

 This table details the file hierarchy schema specification.

| Pattern | Required? | Description |
|--|--|--|
| extras/ | ✓ | Folder for general lab-specific files related to the dataset. |
| raw/ | ✓ | This is a directory containing raw data. |
| raw/dbit_seq/ |  | This is a directory containing raw data exclusive to DBiT-seq. |
| lab_processed/ | ✓ | Experiment files that were processed by the lab generating the data. |
| lab_processed/dbit_seq/ |  | Experiment files that were processed by the lab generating the data exclusive to DBiT-seq. |


## Directory Tree

Here the file hierarchy schema is represented as a directory tree.

```
.
├── extras/
├── raw/
│   └── dbit_seq/
└── lab_processed/
    └── dbit_seq/
```

## YAML

This is file hierarchy schema as YAML code that can be use with the HuBMAP [Ingest Validation Tools](https://github.com/hubmapconsortium/ingest-validation-tools)

```yaml
files:
- pattern: extras\/.*
  required: true
  description: Folder for general lab-specific files related to the dataset.
- pattern: raw\/.*
  required: true
  description: This is a directory containing raw data.
- pattern: raw\/dbit_seq\/.*
  required: false
  description: This is a directory containing raw data exclusive to DBiT-seq.
- pattern: lab_processed\/.*
  required: true
  description: Experiment files that were processed by the lab generating the data.
- pattern: lab_processed\/dbit_seq\/.*
  required: false
  description: Experiment files that were processed by the lab generating the data
    exclusive to DBiT-seq.
```
