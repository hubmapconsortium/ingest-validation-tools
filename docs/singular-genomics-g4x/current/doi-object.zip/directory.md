# Singular Genomics G4X

## File Hierarchy Schema

 This table details the file hierarchy schema specification.

| Pattern | Required? | Description |
|--|--|--|
| extras/ | ✓ | Folder for general lab-specific files related to the dataset. |
| raw/ | ✓ | This is a directory containing raw data. |
| raw/g4x/ |  | This is a directory containing raw data exclusive to G4X. |
| lab_processed/ | ✓ | Experiment files that were processed by the lab generating the data. |
| lab_processed/g4x/ |  | Experiment files that were processed by the lab generating the data exclusive to G4X. |


## Directory Tree

Here the file hierarchy schema is represented as a directory tree.

```
.
├── extras/
├── raw/
│   └── g4x/
└── lab_processed/
    └── g4x/
```

## YAML

This is file hierarchy schema as YAML code that can be use with the HuBMAP [Ingest Validation Tools](https://github.com/hubmapconsortium/ingest-validation-tools)

```yaml
files:
- pattern: extras\/.*
  required: true
  description: Folder for general lab-specific files related to the dataset.
- pattern: raw\/.*
  required: true
  description: This is a directory containing raw data.
- pattern: raw\/g4x\/.*
  required: false
  description: This is a directory containing raw data exclusive to G4X.
- pattern: lab_processed\/.*
  required: true
  description: Experiment files that were processed by the lab generating the data.
- pattern: lab_processed\/g4x\/.*
  required: false
  description: Experiment files that were processed by the lab generating the data
    exclusive to G4X.
```
