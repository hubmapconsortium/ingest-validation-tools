# Microct

## File Hierarchy Schema

 This table details the file hierarchy schema specification.

| Pattern | Required? | Description |
|--|--|--|
| TODO | ✓ | Directory structure not yet specified. |
| extras/ | ✓ | Folder for general lab-specific files related to the dataset. [Exists in all assays] |


## Directory Tree

Here the file hierarchy schema is represented as a directory tree.

```
.
├── TODO
└── extras/
```

## YAML

This is file hierarchy schema as YAML code that can be use with the HuBMAP [Ingest Validation Tools](https://github.com/hubmapconsortium/ingest-validation-tools)

```yaml
files:
- pattern: TODO
  description: Directory structure not yet specified.
  required: true
- pattern: extras\/.*
  required: true
  description: Folder for general lab-specific files related to the dataset. [Exists
    in all assays]
```
