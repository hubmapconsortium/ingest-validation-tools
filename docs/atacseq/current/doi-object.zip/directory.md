# Atacseq

## File Hierarchy Schema

 This table details the file hierarchy schema specification.

| Pattern | Required? | Description |
|--|--|--|
| extras/ | ✓ | Folder for general lab-specific files related to the dataset. |
| raw/ | ✓ | All raw data files for the experiment. |
| raw/fastq/ | ✓ | Raw sequencing files for the experiment. |
| raw/fastq/ATAC/ | ✓ | Directory containing fastq files pertaining to ATACseq sequencing. |
| raw/fastq/ATAC/*_R*.fastq.gz$ | ✓ | This is a GZip'd version of the fastq files containing the forward, reverse and barcode reads from ATACseq sequencing (R1, R2 and R3). Further, if the barcodes are in R2 (as with 10X) then the metadata field "barcode reads" would be set to "Read 2 (R2)" and the fastq file named "*_R2*fastq.gz" would be expected. |
| lab_processed/ |  | Experiment files that were processed by the lab generating the data. |


## Directory Tree

Here the file hierarchy schema is represented as a directory tree.

```
.
├── extras/
├── raw/
│   └── fastq/
│       └── ATAC/
│           └── *_R*.fastq.gz$
└── lab_processed/
```

## YAML

This is file hierarchy schema as YAML code that can be use with the HuBMAP [Ingest Validation Tools](https://github.com/hubmapconsortium/ingest-validation-tools)

```yaml
files:
- pattern: extras\/.*
  required: true
  description: Folder for general lab-specific files related to the dataset.
- pattern: raw\/.*
  required: true
  description: All raw data files for the experiment.
- pattern: raw\/fastq\/.*
  required: true
  description: Raw sequencing files for the experiment.
- pattern: raw\/fastq\/ATAC\/.*
  required: true
  description: Directory containing fastq files pertaining to ATACseq sequencing.
- pattern: raw\/fastq\/ATAC\/[^\/]+_R[^\/]+\.fastq\.gz$
  required: true
  description: This is a GZip'd version of the fastq files containing the forward,
    reverse and barcode reads from ATACseq sequencing (R1, R2 and R3). Further, if
    the barcodes are in R2 (as with 10X) then the metadata field "barcode reads" would
    be set to "Read 2 (R2)" and the fastq file named "*_R2*fastq.gz" would be expected.
  is_qa_qc: false
- pattern: lab_processed\/.*
  required: false
  description: Experiment files that were processed by the lab generating the data.
```
