# Cytof

## File Hierarchy Schema

 This table details the file hierarchy schema specification.

| Pattern | Required? | Description |
|--|--|--|
| extras/ | ✓ | Folder for general lab-specific files related to the dataset. |
| raw/ | ✓ | This is a directory containing raw data. |
| raw/*.{xlsx,txt}$ |  | Instrument calibration file |
| raw/*.imd$ |  | The Integrated Mass Data (IMD) file contains raw, unprocessed data from a CyTOF mass cytometer, including the intensity measurements of each metal ion channel for every cell detected during a sample run, essentially providing the raw signal for each cell across all measured markers in a single file. This data is later converted into a more standard FCS file for analysis. |
| raw/*.fcs$ |  | Contains the raw data from a mass cytometry experiment in a matrix where each row represents a single cell and each column represents a different metal-labeled antibody channel, with the values in each cell signifying the ion count detected for that specific metal on that cell, allowing for the analysis of multiple cell surface markers on individual cells. |
| lab_processed/ | ✓ | Experiment files that were processed by the lab generating the data. |
| lab_processed/*.fcs$ | ✓ | [QA/QC] A lab normalized version of the raw FCS file described above. |


## Directory Tree

Here the file hierarchy schema is represented as a directory tree.

```
.
├── extras/
├── raw/
│   ├── *.{xlsx,txt}$
│   ├── *.imd$
│   └── *.fcs$
└── lab_processed/
    └── *.fcs$
```

## YAML

This is file hierarchy schema as YAML code that can be use with the HuBMAP [Ingest Validation Tools](https://github.com/hubmapconsortium/ingest-validation-tools)

```yaml
files:
- pattern: extras\/.*
  required: true
  description: Folder for general lab-specific files related to the dataset.
- pattern: raw\/.*
  required: true
  description: This is a directory containing raw data.
- pattern: raw\/[^\/]+\.(?:xlsx|txt)$
  required: false
  description: Instrument calibration file
- pattern: raw\/[^\/]+\.imd$
  required: false
  description: The Integrated Mass Data (IMD) file contains raw, unprocessed data
    from a CyTOF mass cytometer, including the intensity measurements of each metal
    ion channel for every cell detected during a sample run, essentially providing
    the raw signal for each cell across all measured markers in a single file. This
    data is later converted into a more standard FCS file for analysis.
- pattern: raw\/[^\/]+\.fcs$
  required: false
  description: Contains the raw data from a mass cytometry experiment in a matrix
    where each row represents a single cell and each column represents a different
    metal-labeled antibody channel, with the values in each cell signifying the ion
    count detected for that specific metal on that cell, allowing for the analysis
    of multiple cell surface markers on individual cells.
  is_qa_qc: false
- pattern: lab_processed\/.*
  required: true
  description: Experiment files that were processed by the lab generating the data.
- pattern: lab_processed\/[^\/]+\.fcs$
  required: true
  description: A lab normalized version of the raw FCS file described above.
  is_qa_qc: true
```
