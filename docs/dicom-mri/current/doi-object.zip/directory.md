# Dicom Mri

## File Hierarchy Schema

 This table details the file hierarchy schema specification.

| Pattern | Required? | Description |
|--|--|--|
| extras/ | ✓ | Folder for general lab-specific files related to the dataset. |
| raw/ | ✓ | This is a directory containing raw data. |
| raw/images/ | ✓ | This is a directory containing raw MRI DICOM files. |
| raw/images/*.dcm$ | ✓ | All relevant MRI DICOM files. |


## Directory Tree

Here the file hierarchy schema is represented as a directory tree.

```
.
├── extras/
└── raw/
    └── images/
        └── *.dcm$
```

## YAML

This is file hierarchy schema as YAML code that can be use with the HuBMAP [Ingest Validation Tools](https://github.com/hubmapconsortium/ingest-validation-tools)

```yaml
files:
- pattern: extras\/.*
  required: true
  description: Folder for general lab-specific files related to the dataset.
- pattern: raw\/.*
  required: true
  description: This is a directory containing raw data.
- pattern: raw\/images\/.*
  required: true
  description: This is a directory containing raw MRI DICOM files.
- pattern: raw\/images\/[^\/]+\.dcm$
  required: true
  description: All relevant MRI DICOM files.
```
