# Raman Imaging

## File Hierarchy Schema

 This table details the file hierarchy schema specification.

| Pattern | Required? | Description |
|--|--|--|
| extras/ | ✓ | Folder for general lab-specific files related to the dataset. |
| raw/ | ✓ | This is a directory containing raw data. |
| raw/raman_imaging/ |  | All relevant raw files for Raman Imaging. |
| lab_processed/ | ✓ | Experiment files that were processed by the lab generating the data. |
| lab_processed/raman_imaging/ |  | All relevant experiment files for Raman Imaging. |


## Directory Tree

Here the file hierarchy schema is represented as a directory tree.

```
.
├── extras/
├── raw/
│   └── raman_imaging/
└── lab_processed/
    └── raman_imaging/
```

## YAML

This is file hierarchy schema as YAML code that can be use with the HuBMAP [Ingest Validation Tools](https://github.com/hubmapconsortium/ingest-validation-tools)

```yaml
files:
- pattern: extras\/.*
  required: true
  description: Folder for general lab-specific files related to the dataset.
- pattern: raw\/.*
  required: true
  description: This is a directory containing raw data.
- pattern: raw\/raman_imaging\/.*
  required: false
  description: All relevant raw files for Raman Imaging.
- pattern: lab_processed\/.*
  required: true
  description: Experiment files that were processed by the lab generating the data.
- pattern: lab_processed\/raman_imaging\/.*
  required: false
  description: All relevant experiment files for Raman Imaging.
```
