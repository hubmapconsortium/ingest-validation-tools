# Maldi

## File Hierarchy Schema

 This table details the file hierarchy schema specification.

| Pattern | Required? | Description |
|--|--|--|
| extras/ | ✓ | Folder for general lab-specific files related to the dataset. |
| extras/mass-spec_environment.{json,tsv}$ |  | JSON or TSV file containing the machine parameters/settings. This is akin to the microscope_environment.json file that's used to describe the imaging equipment. |
| raw/ | ✓ | Raw data files for the experiment. |
| raw/imzML/ | ✓ | Raw mass spec data. |
| raw/imzML/*.ibd$ | ✓ | Mass spec data saved in a binary format. |
| raw/imzML/*.imzML$ | ✓ | Mass spec metadata saved in XML format. Index to .ibd file. |
| lab_processed/ | ✓ | Experiment files that were processed by the lab generating the data. |
| lab_processed/images/ | ✓ | Processed image files |
| lab_processed/images/*.ome.tiff$ | ✓ | OME-TIFF files (multichannel, multi-layered) produced by the microscopy experiment. If compressed, must use loss-less compression algorithm. See the following link for the set of fields that are required in the OME TIFF file XML header. <https://docs.google.com/spreadsheets/d/1YnmdTAA0Z9MKN3OjR3Sca8pz-LNQll91wdQoRPSP6Q4/edit#gid=0> |
| lab_processed/images/*ome-tiff.channels.csv$ | ✓ | This file provides essential documentation pertaining to each channel of the accommpanying OME TIFF. The file should contain one row per OME TIFF channel. The required fields are detailed <https://docs.google.com/spreadsheets/d/1xEJSb0xn5C5fB3k62pj1CyHNybpt4-YtvUs5SUMS44o/edit#gid=0> |
| lab_processed/transformations/ |  | Directory containing image transformations. |
| lab_processed/transformations/*.txt$ |  | Transformations/map back to autofluorescence microscopy (related) data |
| lab_processed/annotations/ | ✓ | Directory containing annotations |
| lab_processed/annotations/*_MolecularAssignments.tsv$ | ✓ | TSV file containing the m/z, molecular assignment, etc. |


## Directory Tree

Here the file hierarchy schema is represented as a directory tree.

```
.
├── extras/
│   └── mass-spec_environment.{json,tsv}$
├── raw/
│   └── imzML/
│       ├── *.ibd$
│       └── *.imzML$
└── lab_processed/
    ├── images/
    │   ├── *.ome.tiff$
    │   └── *ome-tiff.channels.csv$
    ├── transformations/
    │   └── *.txt$
    └── annotations/
        └── *_MolecularAssignments.tsv$
```

## YAML

This is file hierarchy schema as YAML code that can be use with the HuBMAP [Ingest Validation Tools](https://github.com/hubmapconsortium/ingest-validation-tools)

```yaml
files:
- pattern: extras\/.*
  required: true
  description: Folder for general lab-specific files related to the dataset.
- pattern: extras\/mass-spec_environment\.(?:json|tsv)$
  required: false
  description: JSON or TSV file containing the machine parameters/settings. This is
    akin to the microscope_environment.json file that's used to describe the imaging
    equipment.
- pattern: raw\/.*
  required: true
  description: Raw data files for the experiment.
- pattern: raw\/imzML\/.*
  required: true
  description: Raw mass spec data.
- pattern: raw\/imzML\/[^\/]+\.ibd$
  required: true
  description: Mass spec data saved in a binary format.
- pattern: raw\/imzML\/[^\/]+\.imzML$
  required: true
  description: Mass spec metadata saved in XML format. Index to .ibd file.
- pattern: lab_processed\/.*
  required: true
  description: Experiment files that were processed by the lab generating the data.
- pattern: lab_processed\/images\/.*
  required: true
  description: Processed image files
- pattern: lab_processed\/images\/[^\/]+\.ome\.tiff$
  required: true
  description: OME-TIFF files (multichannel, multi-layered) produced by the microscopy
    experiment. If compressed, must use loss-less compression algorithm. See the following
    link for the set of fields that are required in the OME TIFF file XML header.
    <https://docs.google.com/spreadsheets/d/1YnmdTAA0Z9MKN3OjR3Sca8pz-LNQll91wdQoRPSP6Q4/edit#gid=0>
  is_qa_qc: false
- pattern: lab_processed\/images\/[^\/]*ome-tiff\.channels\.csv$
  required: true
  description: This file provides essential documentation pertaining to each channel
    of the accommpanying OME TIFF. The file should contain one row per OME TIFF channel.
    The required fields are detailed <https://docs.google.com/spreadsheets/d/1xEJSb0xn5C5fB3k62pj1CyHNybpt4-YtvUs5SUMS44o/edit#gid=0>
- pattern: lab_processed\/transformations\/.*
  required: false
  description: Directory containing image transformations.
- pattern: lab_processed\/transformations\/[^\/]+\.txt$
  required: false
  description: Transformations/map back to autofluorescence microscopy (related) data
- pattern: lab_processed\/annotations\/.*
  required: true
  description: Directory containing annotations
- pattern: lab_processed\/annotations\/[^\/]+_MolecularAssignments\.tsv$
  required: true
  description: TSV file containing the m/z, molecular assignment, etc.
```
