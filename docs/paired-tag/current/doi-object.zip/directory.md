# Paired Tag

## File Hierarchy Schema

 This table details the file hierarchy schema specification.

| Pattern | Required? | Description |
|--|--|--|
| extras/ | ✓ | Folder for general lab-specific files related to the dataset. |
| extras/expected_cell_count.txt$ |  | The expected cell count for the RNA sequencing dataset. This is an optional file that, if present, will be used by the HIVE's RNA sequencing analysis pipeline. With some datasets, knowing the expected cell count has improved the output of the HIVE analysis pipeline. |
| raw/ | ✓ | All raw data files for the experiment. |
| raw/barcodes.txt$ | ✓ | File containing a list of all barcodes (one per row) to be included in analysis for the RNA sequencing component of the Paired-Tag experiment. This file allows the HIVE/CODCC or anyone else processing the data to determine which barcodes in the RNA fastq files associate with the desired sample to be analyzed within the experiment |
| raw/fastq/ | ✓ | Raw sequencing files for the experiment. |
| raw/fastq/RNA/ | ✓ | Directory containing fastq files pertaining to RNAseq sequencing. |
| raw/fastq/RNA/*_R*.fastq.gz$ | ✓ | This is a GZip'd version of the forward and reverse fastq files from RNAseq sequencing (R1 and R2). |
| raw/fastq/ATAC/ | ✓ | Directory containing fastq files pertaining to ATACseq sequencing. |
| raw/fastq/ATAC/*_R*.fastq.gz$ | ✓ | This is a GZip'd version of the fastq files containing the forward, reverse and barcode reads from ATACseq sequencing (R1, R2 and R3). Further, if the barcodes are in R3 (as with 10X) then the metadata field "barcode reads" would be set to "Read 2 (R2)" and the fastq file named "*_R2*fastq.gz" would be expected. |
| lab_processed/ |  | Experiment files that were processed by the lab generating the data. |


## Directory Tree

Here the file hierarchy schema is represented as a directory tree.

```
.
├── extras/
│   └── expected_cell_count.txt$
├── raw/
│   ├── barcodes.txt$
│   └── fastq/
│       ├── RNA/
│       │   └── *_R*.fastq.gz$
│       └── ATAC/
│           └── *_R*.fastq.gz$
└── lab_processed/
```

## YAML

This is file hierarchy schema as YAML code that can be use with the HuBMAP [Ingest Validation Tools](https://github.com/hubmapconsortium/ingest-validation-tools)

```yaml
files:
- pattern: extras\/.*
  required: true
  description: Folder for general lab-specific files related to the dataset.
- pattern: extras\/expected_cell_count\.txt$
  required: false
  description: The expected cell count for the RNA sequencing dataset. This is an
    optional file that, if present, will be used by the HIVE's RNA sequencing analysis
    pipeline. With some datasets, knowing the expected cell count has improved the
    output of the HIVE analysis pipeline.
- pattern: raw\/.*
  required: true
  description: All raw data files for the experiment.
- pattern: raw\/barcodes.txt$
  required: true
  description: File containing a list of all barcodes (one per row) to be included
    in analysis for the RNA sequencing component of the Paired-Tag experiment. This
    file allows the HIVE/CODCC or anyone else processing the data to determine which
    barcodes in the RNA fastq files associate with the desired sample to be analyzed
    within the experiment
- pattern: raw\/fastq\/.*
  required: true
  description: Raw sequencing files for the experiment.
- pattern: raw\/fastq\/RNA\/.*
  required: true
  description: Directory containing fastq files pertaining to RNAseq sequencing.
- pattern: raw\/fastq\/RNA\/[^\/]+_R[^\/]+\.fastq\.gz$
  required: true
  description: This is a GZip'd version of the forward and reverse fastq files from
    RNAseq sequencing (R1 and R2).
  is_qa_qc: false
- pattern: raw\/fastq\/ATAC\/.*
  required: true
  description: Directory containing fastq files pertaining to ATACseq sequencing.
- pattern: raw\/fastq\/ATAC\/[^\/]+_R[^\/]+\.fastq\.gz$
  required: true
  description: This is a GZip'd version of the fastq files containing the forward,
    reverse and barcode reads from ATACseq sequencing (R1, R2 and R3). Further, if
    the barcodes are in R3 (as with 10X) then the metadata field "barcode reads" would
    be set to "Read 2 (R2)" and the fastq file named "*_R2*fastq.gz" would be expected.
  is_qa_qc: false
- pattern: lab_processed\/.*
  required: false
  description: Experiment files that were processed by the lab generating the data.
```
