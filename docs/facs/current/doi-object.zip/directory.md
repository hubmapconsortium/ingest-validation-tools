# Facs

## File Hierarchy Schema

 This table details the file hierarchy schema specification.

| Pattern | Required? | Description |
|--|--|--|
| extras/ | ✓ | Folder for general lab-specific files related to the dataset. |
| extras/facs_hardware.pdf$ | ✓ | File containing information about the configuration of the instrument, including:number of lasers, power, and wavelength of each; number of filters (if present) and band pass; number of detectors/PMTs. |
| extras/facs_hardware.xlsx$ |  | File containing information about the configuration of the instrument, including:number of lasers, power, and wavelength of each; number of filters (if present) and band pass; number of detectors/PMTs. |
| raw/ | ✓ | This is a directory containing raw data. |
| raw/*.fcs$ |  | Contains the raw data from a mass cytometry experiment in a matrix where each row represents a single cell and each column represents a different metal-labeled antibody channel, with the values in each cell signifying the ion count detected for that specific metal on that cell, allowing for the analysis of multiple cell surface markers on individual cells. |
| raw/*.pdf$ |  | instrument QC and calibration file |
| raw/*.expt$ |  | Contains FACS experiment information (e.g., experiment template, sample names, metadata, etc) |
| raw/*.ust$ |  | Contains FACS instrument information (e.g., laser power, detector voltages, flow rates, thresholds) |
| raw/*.wtml$ |  | Contains FACS worksheets used using data acquisition/analysis |
| raw/*\_bead_compensate.wsp$ |  | FlowJo workspace file created by running specific compensation beads through the flow cytometer, which is then applied to your main experiment data to correct for fluorescence spillover. |
| raw/*.csv$ |  | Single file containing FACS vexperiment information from the instrument. |
| lab_processed/ | ✓ | Experiment files that were processed by the lab generating the data. |
| lab_processed/*.wsp$ | ✓ | [QA/QC] FlowJo workspace file corrected for flourescence spillover via application of the compensation WSP file described above. |


## Directory Tree

Here the file hierarchy schema is represented as a directory tree.

```
.
├── extras/
│   ├── facs_hardware.pdf$
│   └── facs_hardware.xlsx$
├── raw/
│   ├── *.fcs$
│   ├── *.pdf$
│   ├── *.expt$
│   ├── *.ust$
│   ├── *.wtml$
│   ├── *\_bead_compensate.wsp$
│   └── *.csv$
└── lab_processed/
    └── *.wsp$
```

## YAML

This is file hierarchy schema as YAML code that can be use with the HuBMAP [Ingest Validation Tools](https://github.com/hubmapconsortium/ingest-validation-tools)

```yaml
files:
- pattern: extras\/.*
  required: true
  description: Folder for general lab-specific files related to the dataset.
- pattern: extras\/facs_hardware\.pdf$
  required: true
  description: File containing information about the configuration of the instrument,
    including:number of lasers, power, and wavelength of each; number of filters (if
    present) and band pass; number of detectors/PMTs.
- pattern: extras\/facs_hardware\.xlsx$
  required: false
  description: File containing information about the configuration of the instrument,
    including:number of lasers, power, and wavelength of each; number of filters (if
    present) and band pass; number of detectors/PMTs.
- pattern: raw\/.*
  required: true
  description: This is a directory containing raw data.
- pattern: raw\/[^\/]+\.fcs$
  required: false
  description: Contains the raw data from a mass cytometry experiment in a matrix
    where each row represents a single cell and each column represents a different
    metal-labeled antibody channel, with the values in each cell signifying the ion
    count detected for that specific metal on that cell, allowing for the analysis
    of multiple cell surface markers on individual cells.
  is_qa_qc: false
- pattern: raw\/[^\/]+\.pdf$
  required: false
  description: instrument QC and calibration file
- pattern: raw\/[^\/]+\.expt$
  required: false
  description: Contains FACS experiment information (e.g., experiment template, sample
    names, metadata, etc)
- pattern: raw\/[^\/]+\.ust$
  required: false
  description: Contains FACS instrument information (e.g., laser power, detector voltages,
    flow rates, thresholds)
- pattern: raw\/[^\/]+\.wtml$
  required: false
  description: Contains FACS worksheets used using data acquisition/analysis
- pattern: raw\/[^\/]+\_bead_compensate\.wsp$
  required: false
  description: FlowJo workspace file created by running specific compensation beads
    through the flow cytometer, which is then applied to your main experiment data
    to correct for fluorescence spillover.
  is_qa_qc: false
- pattern: raw\/[^\/]+\.csv$
  required: false
  description: Single file containing FACS vexperiment information from the instrument.
  is_qa_qc: false
- pattern: lab_processed\/.*
  required: true
  description: Experiment files that were processed by the lab generating the data.
- pattern: lab_processed\/[^\/]+\.wsp$
  required: true
  description: FlowJo workspace file corrected for flourescence spillover via application
    of the compensation WSP file described above.
  is_qa_qc: true
```
