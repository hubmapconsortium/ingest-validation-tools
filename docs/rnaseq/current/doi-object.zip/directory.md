# Rnaseq

## File Hierarchy Schema

 This table details the file hierarchy schema specification.

| Pattern | Required? | Description |
|--|--|--|
| extras/expected_cell_count.txt$ |  | The expected cell count for the RNA sequencing dataset. This is an optional file that, if present, will be used by the HIVE's RNA sequencing analysis pipeline. With some datasets, knowing the expected cell count has improved the output of the HIVE analysis pipeline. |
| raw/ | ✓ | All raw data files for the experiment. |
| raw/fastq/ | ✓ | Raw sequencing files for the experiment. |
| raw/fastq/RNA/ | ✓ | Directory containing fastq files pertaining to RNAseq sequencing. |
| raw/fastq/RNA/*_R*.fastq.gz$ | ✓ | This is a GZip'd version of the forward and reverse fastq files from RNAseq sequencing (R1 and R2). |
| lab_processed/ |  | Experiment files that were processed by the lab generating the data. |


## Directory Tree

Here the file hierarchy schema is represented as a directory tree.

```
.
├── extras/
│   └── expected_cell_count.txt$
├── raw/
│   └── fastq/
│       └── RNA/
│           └── *_R*.fastq.gz$
└── lab_processed/
```

## YAML

This is file hierarchy schema as YAML code that can be use with the HuBMAP [Ingest Validation Tools](https://github.com/hubmapconsortium/ingest-validation-tools)

```yaml
files:
- pattern: extras\/expected_cell_count\.txt$
  required: false
  description: The expected cell count for the RNA sequencing dataset. This is an
    optional file that, if present, will be used by the HIVE's RNA sequencing analysis
    pipeline. With some datasets, knowing the expected cell count has improved the
    output of the HIVE analysis pipeline.
- pattern: raw\/.*
  required: true
  description: All raw data files for the experiment.
- pattern: raw\/fastq\/.*
  required: true
  description: Raw sequencing files for the experiment.
- pattern: raw\/fastq\/RNA\/.*
  required: true
  description: Directory containing fastq files pertaining to RNAseq sequencing.
- pattern: raw\/fastq\/RNA\/[^\/]+_R[^\/]+\.fastq\.gz$
  required: true
  description: This is a GZip'd version of the forward and reverse fastq files from
    RNAseq sequencing (R1 and R2).
  is_qa_qc: false
- pattern: lab_processed\/.*
  required: false
  description: Experiment files that were processed by the lab generating the data.
```
