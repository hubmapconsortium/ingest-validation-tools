# Music

## File Hierarchy Schema

 This table details the file hierarchy schema specification.

| Pattern | Required? | Description |
|--|--|--|
| extras/ | ✓ | Folder for general lab-specific files related to the dataset. |
| raw/ | ✓ | All raw data files for the experiment. |
| raw/fastq/ | ✓ | Raw sequencing files for the experiment. |
| raw/fastq/*_R*.fastq.gz$ | ✓ | The raw un-multiplexed fastq files. |
| lab_processed/ | ✓ | Experiment files that were processed by the lab generating the data. |
| lab_processed/fastq/DNA/ | ✓ | Directory containing fastq files pertaining to whole genome sequencing. |
| lab_processed/fastq/DNA/*.fastq.gz$ | ✓ | This is a GZip'd version of the fastq files from whole genome sequencing. |
| lab_processed/fastq/RNA/ | ✓ | Directory containing fastq files pertaining to RNAseq sequencing. |
| lab_processed/fastq/RNA/*.fastq.gz$ | ✓ | This is a GZip'd version of the forward and reverse fastq files from RNAseq sequencing (R1 and R2). |


## Directory Tree

Here the file hierarchy schema is represented as a directory tree.

```
.
├── extras/
├── raw/
│   └── fastq/
│       └── *_R*.fastq.gz$
└── lab_processed/
    └── fastq/
        ├── DNA/
        │   └── *.fastq.gz$
        └── RNA/
            └── *.fastq.gz$
```

## YAML

This is file hierarchy schema as YAML code that can be use with the HuBMAP [Ingest Validation Tools](https://github.com/hubmapconsortium/ingest-validation-tools)

```yaml
files:
- pattern: extras\/.*
  required: true
  description: Folder for general lab-specific files related to the dataset.
- pattern: raw\/.*
  required: true
  description: All raw data files for the experiment.
- pattern: raw\/fastq\/.*
  required: true
  description: Raw sequencing files for the experiment.
- pattern: raw\/fastq\/[^\/]+_R[^\/]+\.fastq\.gz$
  required: true
  description: The raw un-multiplexed fastq files.
  is_qa_qc: false
- pattern: lab_processed\/.*
  required: true
  description: Experiment files that were processed by the lab generating the data.
- pattern: lab_processed\/fastq\/DNA\/.*
  required: true
  description: Directory containing fastq files pertaining to whole genome sequencing.
- pattern: lab_processed\/fastq\/DNA\/[^\/]+\.fastq\.gz$
  required: true
  description: This is a GZip'd version of the fastq files from whole genome sequencing.
  is_qa_qc: false
- pattern: lab_processed\/fastq\/RNA\/.*
  required: true
  description: Directory containing fastq files pertaining to RNAseq sequencing.
- pattern: lab_processed\/fastq\/RNA\/[^\/]+\.fastq\.gz$
  required: true
  description: This is a GZip'd version of the forward and reverse fastq files from
    RNAseq sequencing (R1 and R2).
  is_qa_qc: false
```
