# Lcms

## File Hierarchy Schema

 This table details the file hierarchy schema specification.

| Pattern | Required? | Description |
|--|--|--|
| extras/ | ✓ | Folder for general lab-specific files related to the dataset. |
| extras/mass-spec_environment.{json,tsv}$ |  | JSON or TSV file containing the machine parameters/settings. This is akin to the microscope_environment.json file that's used to describe the imaging equipment. |
| raw/ | ✓ | Raw data files for the experiment. |
| raw/*.{raw,mzML}$ |  | Raw mass spectrometry data from an assay of LC-MS, MS, LC-MS Bottom-Up, MS Bottom-Up, LC-MS Top-Down, or MS Top-Down that describes an analyte class of protein, metabolites, lipids, peptides, phosphopeptides, or glycans. |
| raw/analysis.tdf$ |  | SQL file containing all metadata, calibrations, instrument information, etc. for the experiment. |
| raw/analysis.{tsf_bin,tsf,tdf_bin}$ |  | Binary file containing ion mobility data, mass position in time (ns), and intensities. |
| lab_processed/ |  | Lab processed files |
| lab_processed/ID_search_results/ |  | Identification results. |
| lab_processed/ID_search_results/*.csv$ |  | Annotated data describing (qualitative or quantitative) the proteins, metabolites, lipids, peptides, phosphopeptides, or glycans identified from the corresponding raw data. In the case of MS1 this file should include a list of features. |
| lab_processed/ID_metadata/ |  | Identification search parameters/metadata. |
| lab_processed/ID_metadata/*.csv$ |  | Software settings used during the analyte identification process (e.g., from MaxQuant or Proteome Discoverer). |
| lab_processed/QC_results/ |  | Output file resulting from QC analysis. |
| lab_processed/QC_results/*.txt$ |  | A list of metrics with the score of the current dataset that shows the quality of data collection. |


## Directory Tree

Here the file hierarchy schema is represented as a directory tree.

```
.
├── extras/
│   └── mass-spec_environment.{json,tsv}$
├── raw/
│   ├── *.{raw,mzML}$
│   ├── analysis.tdf$
│   └── analysis.{tsf_bin,tsf,tdf_bin}$
└── lab_processed/
    ├── ID_search_results/
    │   └── *.csv$
    ├── ID_metadata/
    │   └── *.csv$
    └── QC_results/
        └── *.txt$
```

## YAML

This is file hierarchy schema as YAML code that can be use with the HuBMAP [Ingest Validation Tools](https://github.com/hubmapconsortium/ingest-validation-tools)

```yaml
files:
- pattern: extras\/.*
  required: true
  description: Folder for general lab-specific files related to the dataset.
- pattern: extras\/mass-spec_environment\.(?:json|tsv)$
  required: false
  description: JSON or TSV file containing the machine parameters/settings. This is
    akin to the microscope_environment.json file that's used to describe the imaging
    equipment.
- pattern: raw\/.*
  required: true
  description: Raw data files for the experiment.
- pattern: raw\/[^\/]+\.(?:raw|mzML)$
  required: false
  description: Raw mass spectrometry data from an assay of LC-MS, MS, LC-MS Bottom-Up,
    MS Bottom-Up, LC-MS Top-Down, or MS Top-Down that describes an analyte class of
    protein, metabolites, lipids, peptides, phosphopeptides, or glycans.
  example: raw/20200707_rmi049_75umPLRPS_Kidney_GF10pc_VAN0003LK32_biorep05_techrep02.raw
- pattern: raw\/analysis\.tdf$
  required: false
  description: SQL file containing all metadata, calibrations, instrument information,
    etc. for the experiment.
- pattern: raw\/analysis\.(?:tsf_bin|tsf|tdf_bin)$
  required: false
  description: Binary file containing ion mobility data, mass position in time (ns),
    and intensities.
- pattern: lab_processed\/.*
  required: false
  description: Lab processed files
- pattern: lab_processed\/ID_search_results\/.*
  required: false
  description: Identification results.
- pattern: lab_processed\/ID_search_results\/[^\/]+\.csv$
  required: false
  description: Annotated data describing (qualitative or quantitative) the proteins,
    metabolites, lipids, peptides, phosphopeptides, or glycans identified from the
    corresponding raw data. In the case of MS1 this file should include a list of
    features.
- pattern: lab_processed\/ID_metadata\/.*
  required: false
  description: Identification search parameters/metadata.
- pattern: lab_processed\/ID_metadata\/[^\/]+\.csv$
  required: false
  description: Software settings used during the analyte identification process (e.g.,
    from MaxQuant or Proteome Discoverer).
- pattern: lab_processed\/QC_results\/.*
  required: false
  description: Output file resulting from QC analysis.
- pattern: lab_processed\/QC_results\/[^\/]+\.txt$
  required: false
  description: A list of metrics with the score of the current dataset that shows
    the quality of data collection.
```
